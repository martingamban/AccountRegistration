﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Account_Registration
{
    public partial class FrmRegistration : Form
    {
        
        public FrmRegistration()
        {
            
            InitializeComponent();
        }

        //Method to Reset all the Textbox and Combobox fields
        public void Reset()
        {
            txtStudentNo.Text = "";
            txt_Address.Text = "";
            txt_Age.Text = "";
            txt_Contact.Text = "";
            txt_Firstname.Text = "";
            txt_Lastname.Text = "";
            txt_Middle.Text = "";
            cbProgram.Text = "";
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            StudentInfoClass.StudentNo = Convert.ToInt64(txtStudentNo.Text);
            StudentInfoClass.ContactNo = Convert.ToInt64(txt_Contact.Text);
            StudentInfoClass.Age = Convert.ToInt64(txt_Age.Text);
            StudentInfoClass.FirstName = txt_Firstname.Text;
            StudentInfoClass.MiddleName = txt_Middle.Text;
            StudentInfoClass.LastName = txt_Lastname.Text;
            StudentInfoClass.Address = txt_Address.Text;
            StudentInfoClass.Program = cbProgram.Text.ToString();

            FrmConfirm confirm = new FrmConfirm();
            confirm.ShowDialog();
            Reset();

        }

        private void txt_Contact_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("Wrong input number!");
            }
        }

        private void txt_Age_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Age_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                MessageBox.Show("Wrong input number!");
            }
        }
    }
}
