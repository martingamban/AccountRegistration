﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Account_Registration
{
    public partial class FrmConfirm : Form
    {
        //Delagates for each variables
        private DelagateText DelProgram, DelLastName, DelFirstName, DelMiddleName, DelAddress;
        private DelegateNumber DelNumage, DelNumContactNo, DelStudNo;
        private void FrmConfirm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        public FrmConfirm()
        {
            InitializeComponent();

            //Delegates to  call static methods
            DelProgram = new DelagateText(StudentInfoClass.GetProgram);
            DelLastName = new DelagateText(StudentInfoClass.GetLastName);
            DelFirstName = new DelagateText(StudentInfoClass.GetFirstName);
            DelMiddleName = new DelagateText(StudentInfoClass.GetMiddleName);
            DelAddress = new DelagateText(StudentInfoClass.GetAddress);

            DelNumage = new DelegateNumber(StudentInfoClass.GetStudentNo);
            DelNumContactNo = new DelegateNumber(StudentInfoClass.GetContactNo);
            DelStudNo = new DelegateNumber(StudentInfoClass.GetStudentNo);
        }

        private void FrmConfirm_Load(object sender, EventArgs e)
        {
            lbl_program.Text = DelProgram(StudentInfoClass.Program);
            lbl_lastname.Text = DelLastName(StudentInfoClass.LastName);
            lbl_firstname.Text = DelFirstName(StudentInfoClass.FirstName);
            lbl_Middle.Text = DelMiddleName(StudentInfoClass.MiddleName);
            lbl_Address.Text = DelAddress(StudentInfoClass.Address);

            lbl_Age.Text = DelNumage(StudentInfoClass.Age).ToString();
            lbl_Contact.Text = DelNumContactNo(StudentInfoClass.ContactNo).ToString();
            lbl_studentno.Text = DelStudNo(StudentInfoClass.StudentNo).ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

    }
}
